# Chat com JGroups
Chat utilizando a biblioteca JGroups, com o objetivo de praticar os conceitos aprendidos na disciplina de Sistemas Distribuídos
- Desenvolvido em Java
- Utilizado a biblioteca JGroups: WebSite -> http://www.jgroups.org/ | GitHub -> https://github.com/belaban/JGroups
- Colega de trabalho: Frederico Hartmann -> https://github.com/Frederico-Hartmann
